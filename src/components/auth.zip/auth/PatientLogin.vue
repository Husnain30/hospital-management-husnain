<template>
  <div class="container mt-5">
    <h3>Patient Login</h3>
    <form @submit.prevent="login">
      <div class="form-group">
        <label>Email</label>
        <input v-model="email" type="email" class="form-control" required />
      </div>
      <div class="form-group">
        <label>Password</label>
        <input v-model="password" type="password" class="form-control" required />
      </div>
      <button type="submit" class="btn btn-primary mt-3">Login</button>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      email: '',
      password: '',
    };
  },
  methods: {
    async login() {
      try {
        const success = await this.$store.dispatch('auth/loginUser', {
          email: this.email,
          password: this.password,
          role: 'patient',
        });

        if (success) {
          this.$router.push('/dashboard/patient');
        } else {
          alert('Invalid credentials for patient.');
        }
      } catch (err) {
        alert('Login failed.');
      }
    },
  },
};
</script>