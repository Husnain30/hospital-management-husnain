<template>
  <div class="container mt-5">
    <h3>Admin Login</h3>
    <form @submit.prevent="login">
      <div class="form-group">
        <label>Email</label>
        <input v-model="email" type="email" class="form-control" required />
      </div>
      <div class="form-group">
        <label>Password</label>
        <input v-model="password" type="password" class="form-control" required />
      </div>
      <button type="submit" class="btn btn-dark mt-3">Login</button>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      email: '',
      password: '',
    };
  },
  methods: {
    async login() {
      const success = await this.$store.dispatch('auth/loginUser', {
        email: this.email,
        password: this.password,
        role: 'admin',
      });

      if (success) {
        this.$router.push('/dashboard/admin');
      } else {
        alert('Invalid credentials for admin.');
      }
    },
  },
};
</script>