<template>
  <div class="container mt-5">
    <h3>Admin Registration</h3>
    <form @submit.prevent="registerAdmin">
      <div class="form-group">
        <label>Username</label>
        <input v-model="form.username" type="text" class="form-control" required />
      </div>
      <div class="form-group">
        <label>Email</label>
        <input v-model="form.email" type="email" class="form-control" required />
      </div>
      <div class="form-group">
        <label>Password</label>
        <input v-model="form.password" type="password" class="form-control" required />
      </div>
      <button type="submit" class="btn btn-dark mt-3">Register</button>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      form: {
        username: '',
        email: '',
        password: '',
      },
    };
  },
  methods: {
    registerAdmin() {
      const user = { ...this.form, role: 'admin' };
      this.$store.commit('auth/REGISTER_USER', user);
      alert('Admin registered!');
      this.$router.push('/admin/login');
    },
  },
};
</script>