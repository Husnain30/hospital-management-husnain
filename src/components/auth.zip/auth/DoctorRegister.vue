<template>
  <div class="container mt-5">
    <h3>Doctor Registration</h3>
    <form @submit.prevent="registerDoctor">
      <div class="form-group">
        <label>Name</label>
        <input v-model="form.name" type="text" class="form-control" required />
      </div>
      <div class="form-group">
        <label>Email</label>
        <input v-model="form.email" type="email" class="form-control" required />
      </div>
      <div class="form-group">
        <label>Password</label>
        <input v-model="form.password" type="password" class="form-control" required />
      </div>
      <div class="form-group">
        <label>Specialization</label>
        <input v-model="form.specialization" type="text" class="form-control" required />
      </div>
      <button type="submit" class="btn btn-success mt-3">Register</button>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      form: {
        name: '',
        email: '',
        password: '',
        specialization: '',
      },
    };
  },
  methods: {
    registerDoctor() {
      const user = { ...this.form, role: 'doctor' };
      this.$store.commit('auth/registerUser', user);
      alert('Doctor registered successfully!');
      this.$router.push('/doctor/login');
    },
  },
};
</script>