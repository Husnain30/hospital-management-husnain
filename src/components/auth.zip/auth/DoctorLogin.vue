<template>
  <div class="container mt-5">
    <h3>Doctor Login</h3>
    <form @submit.prevent="login">
      <div class="form-group">
        <label>Email</label>
        <input v-model="email" type="email" class="form-control" required />
      </div>
      <div class="form-group">
        <label>Password</label>
        <input v-model="password" type="password" class="form-control" required />
      </div>
      <button type="submit" class="btn btn-success mt-3">Login</button>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      email: '',
      password: '',
    };
  },
  methods: {
    async login() {
      try {
        const success = await this.$store.dispatch('auth/loginUser', {
          email: this.email,
          password: this.password,
          role: 'doctor',
        });

        if (success) {
          this.$router.push('/dashboard/doctor');
        } else {
          alert('Invalid credentials for doctor.');
        }
      } catch (err) {
        alert('Login failed.');
      }
    },
  },
};
</script>