<template>
  <div class="container mt-5">
    <h3>Patient Registration</h3>
    <form @submit.prevent="registerPatient">
      <div class="form-group">
        <label>Full Name</label>
        <input v-model="form.name" type="text" class="form-control" required />
      </div>
      <div class="form-group">
        <label>Email</label>
        <input v-model="form.email" type="email" class="form-control" required />
      </div>
      <div class="form-group">
        <label>Password</label>
        <input v-model="form.password" type="password" class="form-control" required />
      </div>
      <div class="form-group">
        <label>Age</label>
        <input v-model="form.age" type="number" class="form-control" required />
      </div>
      <button type="submit" class="btn btn-primary mt-3">Register</button>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      form: {
        name: '',
        email: '',
        password: '',
        age: '',
      },
    };
  },
  methods: {
    registerPatient() {
      const user = { ...this.form, role: 'patient' };
      this.$store.commit('auth/registerUser', user);
      alert('Patient registered successfully!');
      this.$router.push('/patient/login');
    },
  },
};
</script>